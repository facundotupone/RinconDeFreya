<?php
define('DB_HOST', 'srv1548.hstgr.io');
define('DB_USER', 'u811748727_adminrincon');
define('DB_PASS', '3a>Xm~0:TJK');
define('DB_NAME', 'u811748727_rinconfreya');
define('SITE_URL', 'http://localhost/RinconFreya');
?>