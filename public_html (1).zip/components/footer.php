<footer class="footer mt-5 py-4">
    <div class="container text-center">
        <p>Rincón de Freya - Aromas Ancestrales © <?php echo date('Y'); ?></p>
    </div>
</footer>